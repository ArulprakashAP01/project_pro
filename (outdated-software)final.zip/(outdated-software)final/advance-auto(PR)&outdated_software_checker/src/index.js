const { Probot } = require('probot');
const axios = require('axios');
const semver = require('semver');
require('dotenv').config();

/**
 * @param {Probot} app
 */
module.exports = (app) => {
  app.log.info('Outdated Software Checker is running!');

  // Schedule the check to run daily
  const schedule = process.env.SCHEDULE || '0 0 * * *';
  
  app.on('schedule.repository', async (context) => {
    await checkDependencies(context);
  });

  app.on(['installation.created', 'installation_repositories.added'], async (context) => {
    await checkDependencies(context);
  });

  async function checkDependencies(context) {
    const repo = context.payload.repository;
    const owner = repo.owner.login;
    const repoName = repo.name;

    try {
      // Get package.json content
      let npmDeps = [];
      let pipDeps = [];

      try {
        const { data: packageJson } = await context.octokit.repos.getContent({
          owner,
          repo: repoName,
          path: 'package.json',
        });

        if (packageJson) {
          const content = JSON.parse(Buffer.from(packageJson.content, 'base64').toString());
          npmDeps = await checkNpmDependencies(content.dependencies || {});
        }
      } catch (error) {
        app.log.info('No package.json found');
      }

      try {
        const { data: requirementsTxt } = await context.octokit.repos.getContent({
          owner,
          repo: repoName,
          path: 'requirements.txt',
        });

        if (requirementsTxt) {
          const content = Buffer.from(requirementsTxt.content, 'base64').toString();
          pipDeps = await checkPipDependencies(content);
        }
      } catch (error) {
        app.log.info('No requirements.txt found');
      }

      // Create or update the issue
      const issueBody = generateIssueBody(npmDeps, pipDeps);
      const issueTitle = '📦 Dependency Version Check Report';

      // Check if an issue already exists
      const issues = await context.octokit.issues.listForRepo({
        owner,
        repo: repoName,
        state: 'open',
        creator: 'app',
        labels: ['dependencies'],
      });

      const existingIssue = issues.data.find(issue => issue.title === issueTitle);

      if (existingIssue) {
        await context.octokit.issues.update({
          owner,
          repo: repoName,
          issue_number: existingIssue.number,
          body: issueBody,
        });
      } else {
        await context.octokit.issues.create({
          owner,
          repo: repoName,
          title: issueTitle,
          body: issueBody,
          labels: ['dependencies'],
        });
      }
    } catch (error) {
      app.log.error(error);
    }
  }

  async function checkNpmDependencies(dependencies) {
    const results = [];
    for (const [name, version] of Object.entries(dependencies)) {
      try {
        const currentVersion = version.replace(/[\^~]/g, '');
        const { data } = await axios.get(`https://registry.npmjs.org/${name}`);
        const latestVersion = data['dist-tags'].latest;
        
        results.push({
          name,
          currentVersion,
          latestVersion,
          isOutdated: semver.lt(currentVersion, latestVersion),
        });
      } catch (error) {
        app.log.error(`Error checking npm package ${name}: ${error.message}`);
      }
    }
    return results;
  }

  async function checkPipDependencies(requirementsTxt) {
    const results = [];
    const lines = requirementsTxt.split('\n');
    
    for (const line of lines) {
      if (!line.trim() || line.startsWith('#')) continue;
      
      try {
        const [name, version] = line.split('==');
        const { data } = await axios.get(`https://pypi.org/pypi/${name}/json`);
        const latestVersion = data.info.version;
        
        results.push({
          name,
          currentVersion: version || 'unknown',
          latestVersion,
          isOutdated: version ? semver.lt(version, latestVersion) : true,
        });
      } catch (error) {
        app.log.error(`Error checking pip package ${name}: ${error.message}`);
      }
    }
    return results;
  }

  function generateIssueBody(npmDeps, pipDeps) {
    let body = '# 📦 Dependency Version Check Report\n\n';

    if (npmDeps.length > 0) {
      body += '## NPM Dependencies\n\n';
      body += '| Package | Current Version | Latest Version | Status |\n';
      body += '|---------|----------------|----------------|--------|\n';
      
      npmDeps.forEach(dep => {
        const status = dep.isOutdated ? '⚠️ Outdated' : '✅ Up to date';
        body += `| ${dep.name} | ${dep.currentVersion} | ${dep.latestVersion} | ${status} |\n`;
      });
      
      body += '\n';
    }

    if (pipDeps.length > 0) {
      body += '## PIP Dependencies\n\n';
      body += '| Package | Current Version | Latest Version | Status |\n';
      body += '|---------|----------------|----------------|--------|\n';
      
      pipDeps.forEach(dep => {
        const status = dep.isOutdated ? '⚠️ Outdated' : '✅ Up to date';
        body += `| ${dep.name} | ${dep.currentVersion} | ${dep.latestVersion} | ${status} |\n`;
      });
    }

    return body;
  }
};
